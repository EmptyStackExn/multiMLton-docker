#include "platform.h"

const C_Short_t OS_IO_POLLIN = POLLIN;
const C_Short_t OS_IO_POLLPRI = POLLPRI;
const C_Short_t OS_IO_POLLOUT = POLLOUT;
