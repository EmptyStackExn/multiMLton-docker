#include "platform.h"

const C_Size_t NetHostDB_inAddrSize = sizeof (struct in_addr);
const C_Int_t NetHostDB_INADDR_ANY = INADDR_ANY;
