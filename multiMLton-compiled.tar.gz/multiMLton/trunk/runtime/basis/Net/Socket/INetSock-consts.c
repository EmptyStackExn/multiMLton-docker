#include "platform.h"

const C_Int_t Socket_INetSock_Ctl_IPPROTO_TCP = IPPROTO_TCP;
const C_Int_t Socket_INetSock_Ctl_TCP_NODELAY = TCP_NODELAY;
