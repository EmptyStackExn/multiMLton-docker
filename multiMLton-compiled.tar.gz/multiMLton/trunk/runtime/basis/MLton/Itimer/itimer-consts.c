#include "platform.h"

const C_Int_t MLton_Itimer_PROF = ITIMER_PROF;
const C_Int_t MLton_Itimer_REAL = ITIMER_REAL;
const C_Int_t MLton_Itimer_VIRTUAL = ITIMER_VIRTUAL;
