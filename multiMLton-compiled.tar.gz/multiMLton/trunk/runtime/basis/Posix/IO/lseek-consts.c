#include "platform.h"

const C_Int_t Posix_IO_SEEK_CUR = SEEK_CUR;
const C_Int_t Posix_IO_SEEK_END = SEEK_END;
const C_Int_t Posix_IO_SEEK_SET = SEEK_SET;
