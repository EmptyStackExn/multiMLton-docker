#include "platform.h"

void Posix_Process_exit (C_Status_t i) {
  exit (i);
}
