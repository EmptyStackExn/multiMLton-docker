#include "platform.h"

// const C_Int_t Posix_Process_W_CONTINUED = WCONTINUED;
const C_Int_t Posix_Process_W_NOHANG = WNOHANG;
const C_Int_t Posix_Process_W_UNTRACED = WUNTRACED;
