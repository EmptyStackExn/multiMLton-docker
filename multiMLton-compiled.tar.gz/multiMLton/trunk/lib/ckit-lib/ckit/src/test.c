void printf();

main () {
 printf("Hello world\n");
}
