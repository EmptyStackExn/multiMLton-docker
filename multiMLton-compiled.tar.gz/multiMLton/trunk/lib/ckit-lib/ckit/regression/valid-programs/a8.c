enum e {
	x1, x2, x3}

main () {
	enum e k;
	k = 45;
}
