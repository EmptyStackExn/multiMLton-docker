main () {
 /* int y[2,3]; */
 int x;
 x = x ? 1,2 : 3,4;
 x = 1,2 + 4;
}
