main () {
  int *i;
  int *j;
  int k;
  k = (i < j);
}
