struct foo {int x; float y;};
union bar  {int x; float y;};

main (){

  char z[][3] = {{"abc"},{"def"}};

  return 0;
}
