extern int narn (int,int,int);

int *i;

static char *c;

static char mimbar (char c,long l,double d) {
  static int k;

  k = narn (k,k+2,k+3);
  return c;
}

int narn (int x,int y,int z) {
  return (x+y+z);
}

void main ()
{ 
  register int j;

  static int k;

  return;
}




