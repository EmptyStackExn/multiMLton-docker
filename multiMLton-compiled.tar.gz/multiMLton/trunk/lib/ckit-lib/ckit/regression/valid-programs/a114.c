int i = 5;

static int j;

main () {
  return i-5;
}
