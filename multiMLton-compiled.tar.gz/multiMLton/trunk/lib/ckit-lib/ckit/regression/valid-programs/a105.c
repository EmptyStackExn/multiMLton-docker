typedef int (*Rsdefkey_f) (int *,char *,int);

typedef char mystring[10];

main () {
  int j;
  mystring s;

  s[0]='a';
  s[9]='j';
  s[10]='k';
  return j;

}

