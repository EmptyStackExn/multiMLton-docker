f() {
 int i = 1;
}

main () {
  int j;
  j = sizeof(5);
}
