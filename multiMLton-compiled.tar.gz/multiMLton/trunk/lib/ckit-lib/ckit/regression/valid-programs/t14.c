void printf();

struct {int x; int y;} z = {1,2};

int main ()
{ 
  int i = 0;

  i = z.x;
  printf ("i = %d\n",i);
}




