typedef int foo;

int f (int y)
{ 
  int foo = 1;
  return (foo+y);
}


int main ()
{
  return f(1);
}
