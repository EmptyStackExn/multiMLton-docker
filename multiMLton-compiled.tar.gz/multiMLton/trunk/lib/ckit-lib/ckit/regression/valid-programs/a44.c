/* a37.c */
/* Chandra bug, 5/25/99 */

void f(void) {
}


int main()
{
   f();

   return 0;
}
