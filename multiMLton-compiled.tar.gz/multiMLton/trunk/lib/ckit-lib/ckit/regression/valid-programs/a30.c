void *f(int x) {
 return((void *) (((int) f) + x) );
}

main () {
 return(0);
}
