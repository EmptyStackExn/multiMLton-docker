void printf();

typedef int mynum;

struct num {
  short mantissa;
  short exponent;
};

typedef union {
  short mantissaa;
  short exponentt;
} xxx;

typedef union {
  short mantissaa;
  short exponentt;
} xx;


enum dino { L, S};


mynum main () {
	printf("");
}
