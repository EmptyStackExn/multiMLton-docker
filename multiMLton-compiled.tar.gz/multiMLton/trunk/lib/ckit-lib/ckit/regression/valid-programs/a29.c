enum A {
 x1, x2
};

enum B {
 y1, y2
};

int i;

int i;

main () {
 return(0);
}

