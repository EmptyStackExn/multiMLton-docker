struct bar {struct {int n;} m;} a, b, c;

main () {

  typedef struct foo {struct {int n;} m;} baz;

  struct foo *p,pp;

  

}
