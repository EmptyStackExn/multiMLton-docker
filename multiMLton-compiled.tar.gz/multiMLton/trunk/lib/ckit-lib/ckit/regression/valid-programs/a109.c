struct foo *x;

main (){

}
