void *y;
void *x;

void *y = &x;

void *x = &y;

main() {
 1;
}
