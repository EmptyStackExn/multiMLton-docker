/* null function pointers */

void f(int *x) {
  return;
}

void main(){
 f(0);
}

