main (){
  int * const x, y;

  y = 3;

}
