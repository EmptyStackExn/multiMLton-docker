/* null function pointers */

void f(int(* goo)(int)){}

void main(){
 f(0);
}

