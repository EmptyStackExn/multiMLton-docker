void printf();

main() {
  int i;
  char c[] = "5";
  const char cc[] = "5";

  return 1;
}
