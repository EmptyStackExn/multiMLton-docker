enum X {
 x1, x2, x3
 }

main () {
  enum X i;
  int k;
  k = -i;
}
