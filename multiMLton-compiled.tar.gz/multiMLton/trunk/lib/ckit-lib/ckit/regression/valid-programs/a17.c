main() {

  int i;

  i += i;
  i -= i;
  i &= i;
}
