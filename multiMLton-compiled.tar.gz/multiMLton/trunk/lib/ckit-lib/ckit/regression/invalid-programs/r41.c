int f();

int f(int c) {
  return(c);
}



main()
{
  char c;
  f(c);

}


int f(int,int);
