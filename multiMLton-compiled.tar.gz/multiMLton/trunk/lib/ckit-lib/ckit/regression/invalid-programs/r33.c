main () {
 const int y = 1;
 y=2; 
}
