main () {
 return(0);
}

f(int x, int x) {
  x = x;
}

