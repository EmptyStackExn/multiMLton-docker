main () {
  int *i, *j;
  i != 0;
  i > 0;
  i >= 0;
}
