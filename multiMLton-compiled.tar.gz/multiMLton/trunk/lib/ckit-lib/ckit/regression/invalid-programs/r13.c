main () {
  float d;
  int *i;
  i = i + d;
}
