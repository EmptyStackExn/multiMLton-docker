union S {
  int i;
  int j;
};

main () {

  struct S i ;

  switch(i) {
	case 1: 
	case 2: 45;
	default: 45;;;;
	}

  if(i) { 1; }

  while(i) { 2; }

  for(1; i; 2);
  for(i; 1; 2);
  
  do {3;} while (i);
}

