struct X {
 struct X x;
 int y;
};

enum X {
 a1, a2 
};


int f(int);

extern int f();

int f (int x) {
 return(x);
}

int tmp =0;

int f ();

main() {
/*
 struct X {
	 int xxx;
 };	
*/

  int f, kkkkkkkkkkk;
  struct {
    int x;
  } X;
  int tmp;
  double y;
  int i = (int) y;

  f = f + 1;

}

