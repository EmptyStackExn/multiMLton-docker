struct qqux {int x;};

main (){

  struct qqux int x;
}
