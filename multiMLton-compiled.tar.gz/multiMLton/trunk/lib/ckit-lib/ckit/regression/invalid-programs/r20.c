struct X {
  int x1;
  int x2;
  int x3;
};

enum Y {
  x1, x2, x3
};

main() {
  int x1 = x1;
  float x2;
  x2 >> x1;

}
