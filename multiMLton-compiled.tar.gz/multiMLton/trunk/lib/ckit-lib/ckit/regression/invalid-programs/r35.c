main () {
 int j;
 const int *y = &j;
 y=&j; 
 *y=3; 

}
