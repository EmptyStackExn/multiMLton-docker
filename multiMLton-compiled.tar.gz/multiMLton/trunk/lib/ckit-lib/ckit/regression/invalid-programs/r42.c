main () {
  int (*x)[2];
  int (*y)[4];
 
  x = y;
}
