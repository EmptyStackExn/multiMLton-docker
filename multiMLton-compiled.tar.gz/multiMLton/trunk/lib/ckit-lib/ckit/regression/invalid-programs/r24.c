struct X {
  int x1;
  int x2;
  int x3;
};

enum X {
  a1, a2
};

main() {
  struct X y, z;
  float x2;
  return(0);
}
