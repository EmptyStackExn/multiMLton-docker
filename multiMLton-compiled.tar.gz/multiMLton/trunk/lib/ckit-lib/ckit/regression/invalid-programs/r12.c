main () {
  void *i;
  int *j;
  j >= i;
}
