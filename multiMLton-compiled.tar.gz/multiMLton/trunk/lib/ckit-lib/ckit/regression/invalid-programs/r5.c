main () {

  int j[4];
  int i[4] = j;
}
