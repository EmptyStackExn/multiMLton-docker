
main () {
struct X {
  int y;
};

struct X;
struct X;

struct X {
  int y;
};


 return(1);
}




