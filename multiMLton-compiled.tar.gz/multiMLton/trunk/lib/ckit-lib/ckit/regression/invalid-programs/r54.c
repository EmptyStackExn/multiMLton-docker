int (f())[];


main(){
 return(0);
}
