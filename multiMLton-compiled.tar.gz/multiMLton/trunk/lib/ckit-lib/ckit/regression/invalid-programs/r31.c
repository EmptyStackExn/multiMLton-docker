struct X aa;

struct X {
 struct X x;
 int y;
};

main() {
 return(0);
}
