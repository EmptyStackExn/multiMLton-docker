
struct t *x;

main () {

 struct t {
  struct s *y;
 };

 (*x).y;

 return(1);
}




