main () {

  const int j;
  j = 5;
}
