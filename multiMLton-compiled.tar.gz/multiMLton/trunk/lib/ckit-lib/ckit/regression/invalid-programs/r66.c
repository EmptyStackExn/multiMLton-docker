main() {
  x->y;
}
