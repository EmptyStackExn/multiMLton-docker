
enum e_t58 {
  x1=0,
  x2=0,
  x3=0
};
enum e_t58 main ()
{
  enum e_t58 k_p446;
  int i_p447;
  int j_p448;
  j_p448 = (i_p447>>x1);
}
