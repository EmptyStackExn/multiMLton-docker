
struct t250 {
  int x;
  int y;
};
struct t250 z={1,2};
void main ()
{
  int i_p1462;
  i_p1462 = 0;
  i_p1462 = (z.x);
  printf ("i = %d\n",i_p1462);
}
