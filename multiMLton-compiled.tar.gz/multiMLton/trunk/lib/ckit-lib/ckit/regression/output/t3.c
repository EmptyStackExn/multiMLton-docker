
int main ()
{
  int i_p1468;
  
doTop_p1469: 
  ;
  i_p1468 = (i_p1468+1);
  i_p1468 = (i_p1468+1);
  if (i_p1468<10) 
    goto doTop_p1469;
  
doTop_p1472: 
  ;
  i_p1468 = (i_p1468-1);
  if (i_p1468>0) 
    goto doTop_p1472;
}
