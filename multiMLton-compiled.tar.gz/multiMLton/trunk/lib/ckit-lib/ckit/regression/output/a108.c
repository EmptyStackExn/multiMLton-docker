
int main ()
{
  int j_p77;
  int i_p78;
  int quesCol_p80;
  i_p78 = 3;
  if (i_p78) 
    quesCol_p80 = 4;
  else
    quesCol_p80 = 5;
  j_p77 = quesCol_p80;
  printf ("i=%d, j=%d\n",i_p78,j_p77);
  return j_p77;
}
