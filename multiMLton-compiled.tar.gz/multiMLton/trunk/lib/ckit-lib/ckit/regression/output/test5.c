
typedef int mynum_t275;
struct num_t276 {
  short mantissa;
  short exponent;
};
union t277 {
  short mantissaa;
  short exponentt;
};
typedef union t277 xxx_t278;
union t279 {
  short mantissaa;
  short exponentt;
};
typedef union t279 xx_t280;
enum dino_t281 {
  L=0,
  S=0
};
mynum_t275 main ()
{
  
  printf ("");
}
