
void *y;
void *x;
void *y=&x;
void *x=&y;
int main ()
{
  
  1;
}
