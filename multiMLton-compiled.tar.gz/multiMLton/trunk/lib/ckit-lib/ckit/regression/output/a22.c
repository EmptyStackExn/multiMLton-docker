
struct X_t34 {
  int x1;
  int x2;
  int x3;
};
enum Y_t35 {
  x1=0,
  x2=0,
  x3=0
};
int main ()
{
  struct X_t34 y_p323;
  struct X_t34 z_p324;
  void *p_p325;
  float x2_p326;
  char *i_p327;
  p_p325 = ((void *) (&x2_p326));
  p_p325 = ((void *) (&y_p323));
  i_p327 = ((char *) p_p325);
}
