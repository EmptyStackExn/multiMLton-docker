
int main ()
{
  int *i_p85;
  int *j_p86;
  i_p85!=0;
  i_p85>j_p86;
  i_p85>=j_p86;
  i_p85<(j_p86+(1*4));
}
