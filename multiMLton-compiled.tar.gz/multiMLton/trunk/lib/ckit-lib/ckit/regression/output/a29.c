
enum A_t48 {
  x1=0,
  x2=0
};
enum B_t49 {
  y1=0,
  y2=0
};
int i;
int i;
int main ()
{
  
  return 0;
}
