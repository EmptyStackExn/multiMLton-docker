
void * f (int x_p384)
{
  
  return (void *) (((int) f)+x_p384);
}
int main ()
{
  
  f (3);
}
