
int t (int *,int );
int main ()
{
  int j_p73[10];
  int i_p74;
  int *volatile *p_p75;
  i_p74 = 4;
  return i_p74;
}
