
extern int narn (int,int,int);
int *i;
static char *c;
static char mimbar (char c_p1532,long l_p1533,double d_p1534)
{
  static int k_p1535;
  int call_p1543;
  call_p1543 = narn (k_p1535,k_p1535+2,k_p1535+3);
  k_p1535 = call_p1543;
  return c_p1532;
}
int narn (int x_p1537,int y_p1538,int z_p1539)
{
  
  return (x_p1537+y_p1538)+z_p1539;
}
void main ()
{
  register int j_p1541;
  static int k_p1542;
  return ;
}
