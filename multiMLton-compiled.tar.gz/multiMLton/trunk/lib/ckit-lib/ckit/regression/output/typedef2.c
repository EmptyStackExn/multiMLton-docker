
typedef int foo_t283;
int f (int y_p1656)
{
  int foo_p1657;
  foo_p1657 = 1;
  return foo_p1657+y_p1656;
}
int main ()
{
  
  return f (1);
}
