
int main ()
{
  int x_p284;
  int y_p285[3];
  int pref_p287;
  int volatile j_p286;
  x_p284 = 1;
  y_p285[0] = 2;
  y_p285[1] = 1;
  y_p285[2] = 3;
  x_p284 = (x_p284+1);
  pref_p287 = x_p284;
  j_p286 = pref_p287;
  return x_p284+j_p286;
}
