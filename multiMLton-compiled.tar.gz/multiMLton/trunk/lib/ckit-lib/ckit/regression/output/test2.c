
struct num_t263 {
  short mantissa;
  short exponent;
};
typedef int mynum_t264;
struct numm_t265 {
  mynum_t264 mantissaa;
  short exponentt;
};
typedef struct numm_t265 xxx_t266;
struct nummm_t267 {
  mynum_t264 mantissaaa;
  short exponenttt;
};
struct nummm_t267 v;
typedef struct nummm_t267 nummmmm_t268;
union q1_t269 {
  short qa;
  short qb;
};
typedef union q1_t269 q2_t270;
union q3_t271 {
  short qaa;
  short qbb;
};
typedef union q3_t271 q4_t272;
typedef union t273 q7_t274;
mynum_t264 main ()
{
  
  printf ("");
}
