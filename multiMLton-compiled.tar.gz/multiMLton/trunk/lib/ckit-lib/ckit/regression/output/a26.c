
struct t_t46 {
  enum e_t45 *x;
};
enum e_t45 {
  g1=0,
  g2=0
};
struct s_t47 {
  enum e_t45 *x;
};
int main ()
{
  
  return 1;
}
