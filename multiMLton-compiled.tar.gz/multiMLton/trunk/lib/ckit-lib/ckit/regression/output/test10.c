
int i=2;
int i;
struct t257 {
  int a;
  int b;
};
struct t257 x;
struct t258 {
  int a;
  int b;
};
struct t258 y;
struct S_t259 {
  int a;
  int b;
};
struct S_t259 u;
struct S_t259 v;
int main ()
{
  int i_p1592;
  struct t260 {
    int a;
    int b;
  };
  struct t260 x_p1595;
  struct t261 {
    int a;
    int b;
  };
  struct t261 y_p1598;
  struct S_t262 {
    int a;
    int b;
  };
  struct S_t262 u_p1602;
  struct S_t262 v_p1603;
  i_p1592 = 35;
  v_p1603.a = 1;
  v_p1603.b = 34;
  u_p1602 = v_p1603;
  printf ("%d\n",i_p1592);
}
