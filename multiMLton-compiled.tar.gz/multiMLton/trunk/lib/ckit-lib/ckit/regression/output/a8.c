
enum e_t59 {
  x1=0,
  x2=0,
  x3=0
};
enum e_t59 main ()
{
  enum e_t59 k_p454;
  k_p454 = ((enum e_t59) 45);
}
