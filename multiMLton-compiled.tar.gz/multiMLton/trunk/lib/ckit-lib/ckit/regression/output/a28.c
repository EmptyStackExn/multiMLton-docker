
int main ()
{
  int y_p368;
  y_p368 = 1;
  y_p368;
}
