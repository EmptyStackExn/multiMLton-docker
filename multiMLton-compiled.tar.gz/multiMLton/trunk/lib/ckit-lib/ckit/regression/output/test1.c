
enum nevin_t254 {
  X=3,
  Y=10
};
int i;
int main ()
{
  
  p ();
  printf ("%d\n",i);
  q ();
  printf ("%d\n",i);
}
int p ()
{
  enum dino_t255 {
    L=1,
    S=2
  };
  i = ((int) L);
}
int q ()
{
  enum dino_t256 {
    L=3,
    S=4
  };
  i = ((int) L);
}
