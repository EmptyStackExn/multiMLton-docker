
void foo (char **arg_p112)
{
  
  
}
int main ()
{
  
  return 0;
}
