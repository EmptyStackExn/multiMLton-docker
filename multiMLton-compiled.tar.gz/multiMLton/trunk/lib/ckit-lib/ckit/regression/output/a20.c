
struct X_t21 {
  int x1;
  int x2;
  int x3;
};
enum Y_t22 {
  x1=0,
  x2=0,
  x3=0
};
int main ()
{
  struct X_t21 *y_p196;
  struct X_t21 *z_p197;
  float x2_p198;
  y_p196 = ((struct X_t21 *) 0);
  y_p196==0;
  y_p196>=(z_p197+(1*12));
}
