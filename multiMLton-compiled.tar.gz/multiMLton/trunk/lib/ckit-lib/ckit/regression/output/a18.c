
int f ()
{
  int i_p171;
  i_p171 = 1;
}
int main ()
{
  int j_p173;
  j_p173 = ((int) 4);
}
