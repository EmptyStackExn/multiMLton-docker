
int main ()
{
  int *i_p438;
  int *j_p439;
  int k_p440;
  k_p440 = (i_p438<j_p439);
}
