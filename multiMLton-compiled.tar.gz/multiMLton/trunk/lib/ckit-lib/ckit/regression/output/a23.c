
int main ()
{
  struct X_t37 {
    int y;
  };
  return 1;
}
