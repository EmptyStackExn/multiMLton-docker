
void * f (int x_p381)
{
  
  return (void *) (((int) f)+x_p381);
}
int main ()
{
  
  return 0;
}
