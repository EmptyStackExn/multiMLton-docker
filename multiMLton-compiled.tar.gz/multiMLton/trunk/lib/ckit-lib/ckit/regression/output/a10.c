
enum X_t3 {
  x1=0,
  x2=0,
  x3=0
};
enum Y_t4 {
  y1=0,
  y2=0,
  y3=0
};
int main ()
{
  enum X_t3 i_p33;
  enum Y_t4 k_p34;
  k_p34 = ((enum Y_t4) i_p33);
}
