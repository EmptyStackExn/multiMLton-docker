
typedef int (*Rsdefkey_f_t9) (int *,char *,int);
typedef char mystring_t10[10];
int main ()
{
  int j_p64;
  mystring_t10 s_p65;
  s_p65[0] = ((char) 97);
  s_p65[9] = ((char) 106);
  s_p65[10] = ((char) 107);
  return j_p64;
}
