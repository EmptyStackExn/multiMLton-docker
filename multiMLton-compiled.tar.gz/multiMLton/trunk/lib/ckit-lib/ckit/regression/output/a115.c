
extern int i;
static int j;
int main ()
{
  
  return j;
}
