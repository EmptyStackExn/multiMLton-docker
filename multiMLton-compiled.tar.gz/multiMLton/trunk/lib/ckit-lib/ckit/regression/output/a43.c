
int main ()
{
  int *i_p1786;
  int *j_p1787;
  i_p1786 = (j_p1787+(1*4));
}
